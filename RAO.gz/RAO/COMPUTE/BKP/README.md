Local Requirements :

    OS : Oracle Linux 7
    Network : OCNA Highly recommended
    Terraform Version :

        [jmrothst@localhost ~]$ rpm -qa | grep terraform
        terraform-0.11.11-1.el7.x86_64
        terraform-provider-oci-3.12.0-1.el7.x86_64
        [jmrothst@localhost ~]$

    Ensure your Oracle Linux 7 VM has the "ol7_developer" and "ol7_developer_EPEL"
    repository enabled via :

        yum-config-manager --enable ol7_developer ol7_developer_EPEL

    If you lack the yum-config-manager command, install as follows :

        yum -y install yum-utils

    Install Terraform and the OCI provider as follows :

        yum -y install terraform terraform-provider-oci

    Please ensure the versions installed are equal to or newer than the ones listed above.

Step 1 : Set REGION in vars.tf

    Search for "region" and replace "CHANGE_ME" with one of the following : 

        eu-frankfurt-1
        us-phoenix-1
        us-ashburn-1
        uk-london-1

Step 2 : Set DC_CODE in vars.tf

    Search for "dc_code and replace "CHANGE_ME" with one of the following : 

        dc_code		region name from above
	caa		us-phoenix-1
	cab		us-ashburn-1
	cba		eu-frankfurt-1
	cbb		uk-london-1

    See further details at https://confluence.oraclecorp.com/confluence/display/AUOOO/Host+Naming+Conventions

Step 3 : Set REGION_ID in input_conf.tf

    Search for "REGION_ID" and replace "CHANGE_ME" with one of the following

        REGION_ID	region name from above
	PHX		us-phoenix-1
	IAD		us-ashburn-1
	FRA		eu-frankfurt-1
	LHR		uk-london-1

Step 4 : Set AD in input_conf.tf

    Search for "AD" and replace "CHANGE_ME" with the Availability Domain number. 
    This is usally the nubmer "1".

Step 5 : Set CUST_ID in input_conf.tf

    Search for "CUST_ID" and replace "CHANGE_ME" with the 4 letter customer ID.

Step 6 : Set EBSCAT_HOSTNAME in input_conf.tf

    Customers requesting the EBSO Orchestration server need this additional value 
    changed.

    Search for "EBSCAT_HOSTNAME" and replace "CHANGE_ME" with a ten (10) letter 
    value computed as follows : 

    4 Letter Customer ID (Same value CUST_ID was set to)

    3 Letters for "EBS"

    3 Letters of "ORC" for Primary site, and "OR1" for the DR site.

    Final value should appear as "xxxxEBSORC" for primary and "xxxxEBSOR1" for DR 
    with "xxxx" being the customer's 4 letter code.

Step 7 : Review examples in main.tf

    Enabled defaults are provided and correct for WebProxy, Prod SFTP, NonProd 
    SFTP, and Netbackup media servers. Default object storage buckets are 
    enabled. Content for these should not be changed as they match expected 
    values.

    Please review and add additional VM, FSS, and LBaaS as required by the 
    customer.

Step 8 : terraform init

    run : terraform init

Step 9 : terraform plan 

    run : terraform plan

    Expect SSH Key files not to exist and error to be generated

Step 10 : Generate SSH Key files

    Ensure every server built has a unique key as required by our standards, and 
    the strength of the key is strong. The values used are not default values. The
    display_name listed is the display name from main.tf after variable 
    substitution has completed and should have ".pub" appended to it in step 9 
    output.

    ssh-keygen -b 4096 -t rsa -f <display_name>

Step 11 : terraform plan

    Validate no further errors.

Step 12 : terraform apply

